@extends('layouts.app')

@section('title', 'Ajouter une catégorie de recettes')
@section('page-title', 'Ajouter une catégorie')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                <h4 class="card-title mb-0">
                    <i class="fas fa-folder me-2"></i>
                    Nouvelle catégorie de recettes
                </h4>
                <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#revenueCategoryHelpModal" title="Aide">
                    <i class="fas fa-info-circle me-1"></i> Aide
                </button>
            </div>
            <div class="card-body">
                @if ($errors->any())
                    <div class="alert alert-danger mb-4">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('revenue-categories.store') }}" method="POST">
                    @csrf
                    @if(auth()->user()->hasRole('super_admin') && $paroisses->count() > 0)
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Paroisse <span class="text-danger">*</span></label>
                            <select name="paroisse_id" class="form-control" required>
                                @foreach($paroisses as $p)
                                    <option value="{{ $p->id }}" @selected(old('paroisse_id', request('paroisse_id')) == $p->id)>{{ $p->nom }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    @else
                        <input type="hidden" name="paroisse_id" value="{{ auth()->user()->paroisse_id }}">
                    @endif
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Code <span class="text-danger">*</span></label>
                            <input type="text" name="code" class="form-control" value="{{ old('code') }}" required placeholder="ex: quete_ordinaire">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Nom <span class="text-danger">*</span></label>
                            <input type="text" name="nom" class="form-control" value="{{ old('nom') }}" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Ordre</label>
                            <input type="number" name="ordre" class="form-control" value="{{ old('ordre', 0) }}" min="0">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="2">{{ old('description') }}</textarea>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input type="checkbox" name="actif" value="1" class="form-check-input" id="actif" @checked(old('actif', true))>
                                <label class="form-check-label" for="actif">Actif</label>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 pt-3 border-top">
                        <a href="{{ route('revenue-categories.index') }}" class="btn btn-secondary">Annuler</a>
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@include('revenue-categories._help_modal')
@endsection
